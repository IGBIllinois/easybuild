#!/usr/bin/env python3

import os
from pathlib import Path

directory=".archive"
credFile="credentials"
archiveName="bioarchive.data.igb.illinois.edu"
pathToFile=str(Path.home())+"/"+directory+"/"+credFile

#function to make credentials file
def createEnvVars():
  accessID=input("Enter S3 Access ID:")
  secretKey=input("Enter S3 Secret Key:")
  file=open(pathToFile,"w")
  file.write('export DS3_ACCESS_KEY='+accessID+'\n')
  file.write('export DS3_SECRET_KEY='+secretKey+'\n')
  file.write('export DS3_ENDPOINT='+archiveName+'\n')

def modifyBashrc():
  if os.path.isfile('.bashrc'):
    if 'source .archive/credentials' in open('.bashrc').read():
      print("Archive variables already loaded in .bashrc")
    else:
      print("editing .bashrc to load archive credentials on next boot")
      env=open('.bashrc', 'a')
      env.write('source .archive/credentials')
  else:
    print(".bashrc is not found.  Cannot configure environment for archive.")

#see what needs doe be done in credentials file  
if os.path.isfile(pathToFile):
  print("Archive variables exist")
elif os.path.isdir(str(Path.home())+"/"+directory):
  print("Directory exists, but file does not")
  createEnvVars()
  #modifyBashrc()
  print("Environment updated for next login.  To use new values in this session, please type 'source .archive/credentials'")
else:
  print("Make directory and create archive variables")
  os.makedirs(str(Path.home())+"/"+directory)
  createEnvVars()
  #modifyBashrc()
  print("Environment updated for next login.  To use new values in this session, please type 'source .archive/credentials'")

